OK_FORMAT = True

test = {   'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> eq1 != expected_answer_eq1\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> eq2 != expected_answer_eq2\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
