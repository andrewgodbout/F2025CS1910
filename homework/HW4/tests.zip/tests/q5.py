OK_FORMAT = True

test = {'name': 'q5', 'points': 1, 'suites': [{'cases': [{'code': '>>> rootbeers == 45\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
