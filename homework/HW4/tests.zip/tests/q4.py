OK_FORMAT = True

test = {'name': 'q4', 'points': 1, 'suites': [{'cases': [{'code': '>>> valid_answers == 19\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
