OK_FORMAT = True

test = {   'name': 'q1',
    'points': 4,
    'suites': [   {   'cases': [   {'code': ">>> user_input1 != 'your variable name where the first user input is stored' and len(user_input1) > 1\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> user_input2 != 'your variable name where the 2nd user input is stored' and len(user_input2) > 1\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> user_input3 != 'your variable name where the 3rd user input is stored' and len(user_input3) > 1\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> user_input4 != 'your variable name where the 4th user input is stored' and len(user_input4) > 1\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
