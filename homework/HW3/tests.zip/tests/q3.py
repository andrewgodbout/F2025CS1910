OK_FORMAT = True

test = {   'name': 'q3',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> import math\n>>> math.isclose(numerator, 0.01126, abs_tol=0.0001)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> import math\n>>> math.isclose(denominator, 0.1268, abs_tol=0.0001)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> import math\n>>> math.isclose(monthly_payment, 88.85, abs_tol=0.01)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
