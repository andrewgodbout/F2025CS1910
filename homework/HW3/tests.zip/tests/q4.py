OK_FORMAT = True

test = {   'name': 'q4',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> buy_property == True or buy_property == False\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
