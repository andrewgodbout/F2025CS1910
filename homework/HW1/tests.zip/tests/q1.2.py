OK_FORMAT = True

test = {'name': 'q1.2', 'points': 1, 'suites': [{'cases': [{'code': '>>> q12number == 44\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
