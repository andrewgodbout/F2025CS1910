OK_FORMAT = True

test = {   'name': 'q0.1',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> q01link != 'Your link here'\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
