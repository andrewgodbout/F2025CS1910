OK_FORMAT = True

test = {   'name': 'q2',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> t2a\n'A'", 'hidden': False, 'locked': False},
                                   {'code': ">>> t2b\n'N'", 'hidden': False, 'locked': False},
                                   {'code': ">>> t2c\n'B'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
