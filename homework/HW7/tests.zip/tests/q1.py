OK_FORMAT = True

test = {   'name': 'q1',
    'points': 4,
    'suites': [   {   'cases': [   {'code': ">>> t1a\n'E'", 'hidden': False, 'locked': False},
                                   {'code': ">>> t1b\n'BUNNY'", 'hidden': False, 'locked': False},
                                   {'code': ">>> t1c\n'BUNNY'", 'hidden': False, 'locked': False},
                                   {'code': ">>> t1d\n'BUNNY'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
