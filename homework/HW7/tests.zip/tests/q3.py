OK_FORMAT = True

test = {   'name': 'q3',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> shift('Z', 1)\n'A'", 'hidden': False, 'locked': False},
                                   {'code': ">>> shift('Y', 2)\n'A'", 'hidden': False, 'locked': False},
                                   {'code': ">>> shift('A', 26)\n'A'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
