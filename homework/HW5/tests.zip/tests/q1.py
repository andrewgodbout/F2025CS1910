OK_FORMAT = True

test = {'name': 'q1', 'points': 1, 'suites': [{'cases': [{'code': ">>> q1_option == 'B'\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
