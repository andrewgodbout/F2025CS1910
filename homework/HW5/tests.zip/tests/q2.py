OK_FORMAT = True

test = {'name': 'q2', 'points': 1, 'suites': [{'cases': [{'code': '>>> branch_count == 8\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
