OK_FORMAT = True

test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> formatted_output.__doc__.lower().find('score') != -1\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
