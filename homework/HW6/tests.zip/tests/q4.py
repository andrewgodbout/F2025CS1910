OK_FORMAT = True

test = {   'name': 'q4',
    'points': 3,
    'suites': [   {   'cases': [{'code': ">>> score_yellow('occur', 'cacti', score_green('occur', 'cacti'))\n'YBGBB'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
